<?php
	session_start();
	header("HTTP/1.1 404 Not Found");
	header("Status: 404 Not Found");
?>
<script>
	window.location.href = "https://kilala.vn/404.html";
</script>