    <div class="notification email">success</div>
    <div class="notification fullname">success</div>
    <div class="notification phone">success</div>
	<p class="copy">
        ©KANSAI TELEVISION CO., LTD. All right reserved. <br />Powered by Kilala Communication
    </p>
    </body>
</html>