<ul class="tabs">
    <li class="tab is-active">
        <a href="#register" class="tab-link">Đăng Ký</a>
    </li>
    <li class="tab">
        <a href="#rules" class="tab-link">Thể lệ tham gia</a>
    </li>
</ul>