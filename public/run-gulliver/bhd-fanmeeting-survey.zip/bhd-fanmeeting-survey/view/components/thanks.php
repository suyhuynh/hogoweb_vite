<div class="tab-contents">
    <div class="thanks-page" id="thanks">
        <div class="thanks-content">
            <h2 style="max-width: 100%;">
                Cám ơn bạn đã tham gia <br class="md-none" /> khảo sát tại fan meeting <br style="display: block;"/>Phiêu lưu cùng Gulliver <br style="display: block;"/> Mùa 4 Reloaded
            </h2>
            <div class="gift-content">
                <p class="gift-title">
                    MÃ DỰ THƯỞNG CỦA BẠN LÀ
                </p>
                <h3 class="gift-code">
                    <?php echo $customer['code']; ?>
                </h3>
                <p><strong>Lưu ý quan trọng:</strong> Bạn nhớ chụp lại màn hình mã số dự thưởng để làm cơ sở nhận giải nhé.</p>
                <p>Chúc bạn may mắn!</p>
            </div>
        </div>
    </div>
</div>