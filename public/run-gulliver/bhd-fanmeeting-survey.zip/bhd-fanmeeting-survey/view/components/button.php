<button name="submit" type="submit" class="button-primary disabled" id="submit-button">
    Xác nhận tham gia
    <div class="loader">
        <div class="inner one"></div>
        <div class="inner two"></div>
        <div class="inner three"></div>
    </div>
</button>