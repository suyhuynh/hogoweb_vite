<!DOCTYPE html>
<html lang="vi">
    <head>
    </head>
    <body style="background: rgba(25, 191, 191, 0.562);">
        <table style="width: 560px;background: #fff;padding: 15px;margin: 30px auto;">
            <thead>
                <tr>
                    <td>
                        <img src="https://beta.kilala.vn/images/logo.png" style="height: 30px;" alt="" />
                        <hr />
                    </td>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <p style="margin: 0;">Chương trình Phiêu lưu cùng Gulliver - Mùa 4 Reloaded đã nhận được bản khảo sát của bạn.</p>
                        <p style="margin: 0;">
                            <strong>
                                Thông tin khảo sát của bạn như sau:
                            </strong>
                        </p>
                        <p style="margin-bottom: 0;"><strong>Mã số dự thưởng:</strong> c9a300f0</p>

                        <p style="margin-bottom: 0;"><strong>Họ tên:</strong> Ngân Tô</p>

                        <p style="margin-bottom: 0;"><strong>Giới tính:</strong> Nam</p>

                        <p style="margin-bottom: 0;"><strong>Độ tuổi:</strong> Từ 30 tuổi</p>

                        <p style="margin-bottom: 0;"><strong>Khu vực:</strong> TP. Hồ Chí Minh</p>

                        <p style="margin-bottom: 0;"><strong>Nghề nhgiệp:</strong> Khác</p>

                        <p style="margin-bottom: 0;"><strong>Điện thoại:</strong> 09000000000</p>
                        <p style="margin-bottom: 0;"><strong>Email:</strong> jinna.to@gmail.com</p>
                        <p>
                            <hr>
                            NỘI DUNG KHẢO SÁT
                            <hr>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0;"><strong>Q1:</strong> sakdjsakjd sakd</p>
                        <ul style="margin-left: 0;padding-left: 15px;padding-top: 0;margin-top: 0;">
                            <li style="list-style: none;">
                                ☐ kadj askjdk asd
                            </li>
                            <li style="list-style: none;">
                                ☑ kadj askjdk asd
                            </li>
                        </ul>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="margin: 0;"><strong>Q2:</strong> sakdjsakjd sakd</p>
                        <ul style="margin-left: 0;padding-left: 15px;padding-top: 0;margin-top: 0;">
                            <li style="list-style: none;">
                                ☐ kadj askjdk asd
                            </li>
                            <li style="list-style: none;">
                                ☑ kadj askjdk asd
                            </li>
                        </ul>
                    </td>
                </tr>

            </tbody>
            <tfoot>
                <tr>
                    <td>
                        <p style="margin-bottom: 0;">Mọi thắc mắc vui lòng liên hệ:</p>
                        <hr />
                        <p style="margin: 0;">
                            <strong>CÔNG TY TNHH TRUYỀN THÔNG KILALA</strong>
                        </p>
                        <p style="margin: 0;">Tầng 3, Tòa nhà Copac Square, 12 Tôn Đản, Phường 13, Quận 4, TP.HCM</p>
                        <p style="margin: 0;"><strong>Phone:</strong> (+84) 28 3827 7722  Thứ 2 – Thứ 6 | 8:30 – 17:00</p>
                        <p style="margin: 0;"><strong>Email:</strong> info@kilala.vn</p>
                        <p style="margin: 0;"><strong>Website:</strong> kilala.vn</p>
                    </td>
                </tr>
            </tfoot>
        </table>
    </body>
</html>