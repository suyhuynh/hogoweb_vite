<script>
    window.location.href = 'https://survey-mn.kilala.vn/login'; 
</script>